# Заняття 1

[Презентація](https://docs.google.com/presentation/d/19ICigSqYhsP755sK6s5ru1VJPItN_OXCGaoCbQCEIiM/edit#slide=id.g1cb789af844_0_104)

[PyCharm](https://www.jetbrains.com/pycharm/download/#section=windows)

