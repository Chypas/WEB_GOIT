from example_02 import baz, foo


if __name__ == "__main__":
    baz()
    foo(25)
